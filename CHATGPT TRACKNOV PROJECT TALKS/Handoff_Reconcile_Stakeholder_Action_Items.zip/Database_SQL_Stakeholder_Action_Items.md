# Database / SQL Stakeholder — Action Items

- Verify all migrations applied.
- Eliminate schema drift.
- Strengthen ENUM/FK/trigger enforcement.
- Enforce immutable audit chains.
- Implement desync repair jobs.
- Strengthen RLS proofing.
