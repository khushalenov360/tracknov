# RBAC / Security Stakeholder — Action Items

- Complete capability-based authorization.
- Verify project isolation.
- Enforce authorization-before-retrieval.
- Verify signed URL governance.
- Implement runtime security automation.
- Audit all APIs for authorization gaps.
