# Tech Lead / Developer — Action Items

- Convert governance into DB-enforced runtime invariants.
- Reduce service-layer dependency.
- Implement reconciliation engine.
- Implement deterministic desync recovery.
- Complete capability-based authorization.
- Implement certification snapshot integrity.
- Prevent hardcoded role logic.
