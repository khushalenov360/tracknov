# Project Manager — Action Items

- Enforce Handoff Reconcile cadence.
- Sync GitHub repo into Project Resources minimum 4 times daily.
- Publish migration application status daily.
- Maintain architecture freeze registry.
- Prevent governance drift.
- Escalate partial implementations immediately.
- Shift focus from feature expansion to runtime stabilization.
