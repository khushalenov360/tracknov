# UX/UI Stakeholder — Action Items

- Align UI with backend authority.
- Surface desync states clearly.
- Improve workflow traceability.
- Add reconciliation dashboards.
- Prevent misleading optimistic UI states.
- Improve assignment visibility.
