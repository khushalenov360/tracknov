# AI / Copilot Stakeholder — Action Items

- Strengthen anti-hallucination governance.
- Enforce tenant-isolated retrieval.
- Implement prompt sanitization.
- Prevent AI workflow mutation.
- Ensure explainability.
- Prevent cross-project retrieval.
